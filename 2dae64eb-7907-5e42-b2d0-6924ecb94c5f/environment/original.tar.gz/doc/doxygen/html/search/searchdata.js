var indexSectionsWithContent =
{
  0: "0123456789_abcdefghijlmnoprstuvwy",
  1: "y",
  2: "y",
  3: "y",
  4: "acdfimnoprstuvy",
  5: "y",
  6: "_y",
  7: "0123456789abcdefghijlmnoprstuvwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Pages"
};

